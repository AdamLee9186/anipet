// Lionwheel Customer Notes (Supabase REST) - Content Script
// Stores notes per customer_key where customer_key = normalized phone (local format, e.g. 052...).

// Cross-browser API (Chrome + Firefox)
const EXT = globalThis.browser ?? globalThis.chrome;

// Hardcoded Supabase config (team deployment)
const SB_URL = "https://xfwxplrtetxlyvppfhaf.supabase.co";
const SB_ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhmd3hwbHJ0ZXR4bHl2cHBmaGFmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc5NjQyMjMsImV4cCI6MjA4MzU0MDIyM30.7rg-gAEUM0kCSD2QKLXjz9ZUkwAjzpeYnTPU8tDrHvA";

// Team tenant (shared notes)
const TENANT_ID = "anipet_team";

const CFG_KEYS = ["sbSession"];

function nowSec() {
  return Math.floor(Date.now() / 1000);
}

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

// Cross-browser storage wrapper (Firefox returns Promise, Chrome uses callbacks)
async function getStore() {
  try {
    const maybePromise = EXT.storage.local.get(CFG_KEYS);
    if (maybePromise && typeof maybePromise.then === "function") return await maybePromise;
  } catch (_) {}
  return await new Promise((resolve, reject) => {
    EXT.storage.local.get(CFG_KEYS, (res) => {
      const err = EXT.runtime?.lastError;
      if (err) reject(err);
      else resolve(res);
    });
  });
}

async function setStore(obj) {
  try {
    const maybePromise = EXT.storage.local.set(obj);
    if (maybePromise && typeof maybePromise.then === "function") return await maybePromise;
  } catch (_) {}
  return await new Promise((resolve, reject) => {
    EXT.storage.local.set(obj, () => {
      const err = EXT.runtime?.lastError;
      if (err) reject(err);
      else resolve();
    });
  });
}

function parseHashTokens() {
  const h = String(location.hash || "");
  if (!h.includes("access_token=") || !h.includes("refresh_token=")) return null;

  const params = new URLSearchParams(h.replace(/^#/, ""));
  const access_token = params.get("access_token");
  const refresh_token = params.get("refresh_token");
  const expires_in = Number(params.get("expires_in") || "3600");
  if (!access_token || !refresh_token) return null;

  return {
    access_token,
    refresh_token,
    expires_at: nowSec() + expires_in - 30
  };
}

async function captureMagicLinkSessionIfPresent() {
  const tok = parseHashTokens();
  if (!tok) return;

  await setStore({ sbSession: tok });

  // Clean URL hash immediately (remove tokens from address bar)
  history.replaceState(null, document.title, location.pathname + location.search);
}

function normalizeIsraeliPhoneToE164(raw) {
  // We intentionally DO NOT use +972/E164 because Lionwheel uses local phone.
  // Normalize to digits only. If number arrives as 972XXXXXXXXX -> convert to 0XXXXXXXXX.
  let s = String(raw || "").trim();
  s = s.replace(/[^\d]/g, "");
  if (!s) return null;
  if (s.startsWith("972") && s.length >= 11) {
    return "0" + s.slice(3);
  }
  return s;
}

function findDestinationPhoneText() {
  // Based on your HTML:
  // <div data-name="destination_phone"> ... <span class="hover-copy">0527...</span>
  const phoneRow = document.querySelector('div.row[data-name="destination_phone"]');
  if (!phoneRow) return null;
  const span = phoneRow.querySelector(".col-xxl-7 .hover-copy");
  const txt = span?.textContent?.trim() || "";
  return txt || null;
}

function findDestinationNameText() {
  // <div class="row ..." data-name="destination_recipient_name"> ... <span class="hover-copy">אדם לי</span>
  const row = document.querySelector('div.row[data-name="destination_recipient_name"]');
  if (!row) return null;
  // Sometimes Lionwheel renders name as a link inside .editable-text (no .hover-copy)
  // Examples:
  // 1) <span class="hover-copy editable-text">...</span>
  // 2) <span class="editable-text"><a ...>...</a></span>
  const span =
    row.querySelector(".col-xxl-7 .hover-copy") ||
    row.querySelector(".col-xxl-7 span.editable-text") ||
    row.querySelector(".col-xxl-7 .editable-text a");
  const txt = span?.textContent?.trim() || "";
  return txt || null;
}

function getAnchorSpanForName() {
  const row = document.querySelector('div.row[data-name="destination_recipient_name"]');
  if (!row) return null;
  // Prefer the actual name span/link, but we will append the button to its container (col-xxl-7).
  return (
    row.querySelector(".col-xxl-7 .hover-copy") ||
    row.querySelector(".col-xxl-7 span.editable-text") ||
    row.querySelector(".col-xxl-7 .editable-text a")
  );
}

function getNameHostEl() {
  const row = document.querySelector('div.row[data-name="destination_recipient_name"]');
  if (!row) return null;
  return row.querySelector(".col-xxl-7");
}

function getAnchorSpanForPhone() {
  const phoneRow = document.querySelector('div.row[data-name="destination_phone"]');
  if (!phoneRow) return null;
  return phoneRow.querySelector(".col-xxl-7 .hover-copy");
}

async function supabaseRefreshToken(sbUrl, sbAnon, refresh_token) {
  const url = `${sbUrl.replace(/\/$/, "")}/auth/v1/token?grant_type=refresh_token`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "apikey": sbAnon,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ refresh_token })
  });
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`Refresh failed (${res.status}): ${t}`);
  }
  const data = await res.json();
  return {
    access_token: data.access_token,
    refresh_token: data.refresh_token,
    expires_at: nowSec() + (data.expires_in || 3600) - 30,
    user_id: data.user?.id || null,
    email: data.user?.email || null
  };
}

async function ensureSession() {
  const { sbSession } = await getStore();
  if (!SB_URL || !SB_ANON) throw new Error("חסר Supabase config בקוד");
  if (!sbSession?.access_token) throw new Error("לא מחובר (פתח Options ושלח Magic Link)");

  if ((sbSession.expires_at || 0) > nowSec() + 10) {
    return { sbUrl: SB_URL, sbAnon: SB_ANON, session: sbSession };
  }

  // Use background script for refresh (cross-browser)
  try {
    const refreshed = await new Promise((resolve, reject) => {
      EXT.runtime.sendMessage({
        type: 'REFRESH_TOKEN',
        data: { refreshToken: sbSession.refresh_token }
      }, (response) => {
        const err = EXT.runtime?.lastError;
        if (err) reject(new Error(err.message));
        else if (!response || !response.success) reject(new Error(response?.error || "שגיאת רענון טוקן"));
        else resolve(response.data);
      });
    });
    const merged = { ...sbSession, ...refreshed };
    await setStore({ sbSession: merged });
    return { sbUrl: SB_URL, sbAnon: SB_ANON, session: merged };
  } catch (bgError) {
    // Fallback to direct refresh if background fails
    const refreshed = await supabaseRefreshToken(SB_URL, SB_ANON, sbSession.refresh_token);
    const merged = { ...sbSession, ...refreshed };
    await setStore({ sbSession: merged });
    return { sbUrl: SB_URL, sbAnon: SB_ANON, session: merged };
  }
}

// --- customer_notes (single note per customer) ---
async function dbCreateCustomerNote({ sbUrl, sbAnon, access_token, user_id, customer_key, note }) {
  const base = sbUrl.replace(/\/$/, "");
  const url = `${base}/rest/v1/customer_notes`;

  const payload = {
    user_id, // IMPORTANT if column is NOT NULL
    customer_key,
    note: String(note || ""),
    updated_at: new Date().toISOString()
  };

  const res = await fetch(url, {
    method: "POST",
    headers: {
      "apikey": sbAnon,
      "Authorization": `Bearer ${access_token}`,
      "Content-Type": "application/json",
      "Prefer": "return=representation"
    },
    body: JSON.stringify(payload)
  });

  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`DB create failed (${res.status}): ${t}`);
  }
  const rows = await res.json();
  return rows?.[0];
}

async function dbUpdateCustomerNote({ sbUrl, sbAnon, access_token, id, note }) {
  const base = sbUrl.replace(/\/$/, "");
  const url =
    `${base}/rest/v1/customer_notes` +
    `?id=eq.${encodeURIComponent(id)}`;

  const payload = {
    note: String(note || ""),
    updated_at: new Date().toISOString()
  };

  const res = await fetch(url, {
    method: "PATCH",
    headers: {
      "apikey": sbAnon,
      "Authorization": `Bearer ${access_token}`,
      "Content-Type": "application/json",
      "Prefer": "return=minimal"
    },
    body: JSON.stringify(payload)
  });

  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`DB update failed (${res.status}): ${t}`);
  }
}

async function dbDeleteCustomerNote({ sbUrl, sbAnon, access_token, id }) {
  const base = sbUrl.replace(/\/$/, "");
  const url =
    `${base}/rest/v1/customer_notes` +
    `?id=eq.${encodeURIComponent(id)}`;

  const res = await fetch(url, {
    method: "DELETE",
    headers: {
      "apikey": sbAnon,
      "Authorization": `Bearer ${access_token}`
    }
  });

  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`DB delete failed (${res.status}): ${t}`);
  }
}

// Background service worker API wrappers (production-ready, cross-browser)
async function saveNoteViaBackground({ customer_key, note }) {
  return new Promise((resolve, reject) => {
    // Check if background service worker is available
    if (!EXT.runtime || !EXT.runtime.sendMessage) {
      reject(new Error("Background service worker not available"));
      return;
    }

    EXT.runtime.sendMessage(
      {
        type: "SAVE_NOTE",
        data: { customer_key, note }
      },
      (response) => {
        const err = EXT.runtime?.lastError;
        if (err) {
          reject(new Error(err.message));
          return;
        }
        if (!response) {
          reject(new Error("No response from background service worker"));
          return;
        }
        if (!response.success) {
          reject(new Error(response.error || "שגיאת שמירה"));
          return;
        }
        resolve(response.data);
      }
    );
  });
}

async function getNoteViaBackground({ customer_key }) {
  return new Promise((resolve, reject) => {
    // Check if background service worker is available
    if (!EXT.runtime || !EXT.runtime.sendMessage) {
      reject(new Error("Background service worker not available"));
      return;
    }

    EXT.runtime.sendMessage(
      {
        type: "GET_NOTE",
        data: { customer_key }
      },
      (response) => {
        const err = EXT.runtime?.lastError;
        if (err) {
          reject(new Error(err.message));
          return;
        }
        if (!response) {
          reject(new Error("No response from background service worker"));
          return;
        }
        if (!response.success) {
          reject(new Error(response.error || "שגיאת קריאה"));
          return;
        }
        resolve(response.data);
      }
    );
  });
}

async function dbGetSingleNote({ sbUrl, sbAnon, access_token, customer_key }) {
  // Validate required parameters
  if (!sbUrl || !sbAnon || !access_token) {
    throw new Error("Missing required parameters for DB call");
  }

  // Try background service worker first, fallback to direct fetch
  try {
    return await getNoteViaBackground({ customer_key });
  } catch (bgError) {
    // Fallback to direct API call if background fails
    // Only log if it's not a "normal" connection error (which is expected)
    const msg = String(bgError?.message || "");
    const expected = msg.includes("Receiving end does not exist") || msg.includes("Could not establish connection") || msg.includes("not available");
    if (!expected) {
      console.warn("Background get failed, falling back to direct API:", msg);
    }
    
    // Use direct API call as fallback
    const base = sbUrl.replace(/\/$/, "");
    const url =
      `${base}/rest/v1/customer_notes` +
      `?select=id,note,updated_at` +
      `&customer_key=eq.${encodeURIComponent(customer_key)}` +
      `&order=updated_at.desc` +
      `&limit=1`;

    const res = await fetch(url, {
      headers: {
        "apikey": sbAnon,
        "Authorization": `Bearer ${access_token}`
      }
    });
    
    if (!res.ok) {
      const t = await res.text().catch(() => "");
      // Provide more helpful error message
      if (res.status === 401) {
        throw new Error(`Invalid API key or expired token (401). Check your Supabase anon key. Response: ${t}`);
      }
      throw new Error(`DB read failed (${res.status}): ${t}`);
    }
    
    const rows = await res.json();
    return rows?.[0] || null;
  }
}

// Fallback: Direct API calls (for backward compatibility or if background fails)
async function dbDeleteByCustomerKey({ sbUrl, sbAnon, access_token, customer_key }) {
  const base = sbUrl.replace(/\/$/, "");
  const url =
    `${base}/rest/v1/customer_notes` +
    `?customer_key=eq.${encodeURIComponent(customer_key)}`;

  const res = await fetch(url, {
    method: "DELETE",
    headers: {
      "apikey": sbAnon,
      "Authorization": `Bearer ${access_token}`
    }
  });

  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`DB delete failed (${res.status}): ${t}`);
  }
}

async function dbSaveSingleNote({ sbUrl, sbAnon, access_token, user_id, customer_key, note }) {
  // Try background service worker first, fallback to direct fetch
  try {
    return await saveNoteViaBackground({ customer_key, note });
  } catch (bgError) {
    // Fallback to direct API call if background fails
    // Only log if it's not a "normal" connection error (which is expected)
    const msg = String(bgError?.message || "");
    const expected = msg.includes("Receiving end does not exist") || msg.includes("Could not establish connection") || msg.includes("not available");
    if (!expected) {
      console.warn("Background save failed, falling back to direct API:", msg);
    }
    
    const cleanNote = String(note || "");

    // empty => delete
    if (!cleanNote.trim()) {
      await dbDeleteByCustomerKey({ sbUrl, sbAnon, access_token, customer_key });
      return null;
    }

    const base = sbUrl.replace(/\/$/, "");
    // UPSERT by customer_key (requires UNIQUE on customer_key)
    const url = `${base}/rest/v1/customer_notes?on_conflict=customer_key`;

    const payload = {
      customer_key,
      user_id,
      note: cleanNote,
      updated_at: new Date().toISOString()
    };

    const res = await fetch(url, {
      method: "POST",
      headers: {
        "apikey": sbAnon,
        "Authorization": `Bearer ${access_token}`,
        "Content-Type": "application/json",
        "Prefer": "resolution=merge-duplicates,return=representation"
      },
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      const t = await res.text().catch(() => "");
      // Make errors actionable
      if (res.status === 401) {
        throw new Error(`Invalid API key or expired token (401). Check your Supabase anon key in content.js. Response: ${t}`);
      }
      if (res.status === 403) throw new Error("אין הרשאות — בדוק RLS/Policies.");
      if (res.status === 409) throw new Error("קונפליקט DB — בדוק UNIQUE/UPSERT.");
      throw new Error(`שגיאת שמירה (${res.status}): ${t}`);
    }

    const rows = await res.json();
    return rows?.[0] || null;
  }
}

async function dbDeleteSingleNote({ sbUrl, sbAnon, access_token, customer_key }) {
  await dbDeleteByCustomerKey({ sbUrl, sbAnon, access_token, customer_key });
}

// Global position tracking state
let activePositionInterval = null;
let activeScrollHandler = null;
let activeUpdatePos = null;
let activeBubbleCleanup = null;

function closeBubble() {
  // Clean up position tracking
  if (activePositionInterval) {
    clearInterval(activePositionInterval);
    activePositionInterval = null;
  }
  if (activeScrollHandler) {
    window.removeEventListener("scroll", activeScrollHandler, { capture: true });
    activeScrollHandler = null;
  }
  activeUpdatePos = null;

  // IMPORTANT: always cleanup document-level listeners from the last bubble
  if (typeof activeBubbleCleanup === "function") {
    try { activeBubbleCleanup(); } catch {}
    activeBubbleCleanup = null;
  }

  // Close both shadow host and regular bubble (for backward compatibility)
  // Don't return early before cleanup!
  const shadowHost = document.querySelector("#lwcn-shadow-host");
  if (shadowHost) {
    shadowHost.remove();
  }
  const regularBubble = document.querySelector(".lwcn-bubble");
  if (regularBubble) {
    regularBubble.remove();
  }
}

function placeBubbleNearFixed(btn, bubble) {
  // Get button position relative to viewport (works with fixed positioning)
  const r = btn.getBoundingClientRect();
  
  // Check if button disappeared (e.g., sidepanel closed)
  if ((r.width === 0 && r.height === 0) || r.top === 0 && r.left === 0 && r.bottom === 0 && r.right === 0) {
    closeBubble();
    return;
  }
  
  // Wait for bubble to be measured (in case it's not yet rendered)
  if (!bubble || bubble.offsetWidth === 0) {
    requestAnimationFrame(() => placeBubbleNearFixed(btn, bubble));
    return;
  }
  
  const bubbleRect = bubble.getBoundingClientRect();
  const bubbleW = bubbleRect.width || 360;
  const bubbleH = bubbleRect.height || 160;
  
  // Calculate viewport position (fixed positioning uses viewport coordinates)
  let viewportLeft = r.left - bubbleW - 12;
  let side = "left";

  // If not enough space on left, place on right
  if (viewportLeft < 8) {
    viewportLeft = r.right + 12;
    side = "right";
  }
  
  // Clamp to viewport boundaries
  viewportLeft = Math.max(8, Math.min(window.innerWidth - bubbleW - 8, viewportLeft));

  // Center vertically relative to button
  let viewportTop = r.top + (r.height / 2) - (bubbleH / 2);
  
  // Clamp to viewport bounds
  viewportTop = Math.max(8, Math.min(window.innerHeight - bubbleH - 8, viewportTop));

  // Position the bubble with fixed positioning (relative to viewport)
  bubble.style.position = "fixed";
  bubble.style.left = `${viewportLeft}px`;
  bubble.style.top = `${viewportTop}px`;
  bubble.style.zIndex = "2147483647";
  
  if (bubble.dataset) bubble.dataset.side = side;

  // Calculate caret position (arrow pointing to button center)
  const caretTop = r.top + (r.height / 2) - viewportTop;
  if (bubble.style) bubble.style.setProperty("--lwcn-caret-top", `${Math.max(18, Math.min(bubbleH - 18, caretTop))}px`);
}

function fmtUpdatedAt(iso) {
  if (!iso) return "";
  try {
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return "";
    return new Intl.DateTimeFormat("he-IL", { dateStyle: "short", timeStyle: "short" }).format(d);
  } catch {
    return "";
  }
}

function formatILDateTime(iso) {
  try {
    const d = new Date(iso);
    return d.toLocaleString("he-IL", {
      year: "numeric",
      month: "numeric",
      day: "numeric",
      hour: "2-digit",
      minute: "2-digit"
    });
  } catch {
    return "";
  }
}

function lwcnNextFrame() {
  return new Promise((r) => requestAnimationFrame(() => r()));
}

async function lwcnWaitForStyledBubble(bubble, maxFrames = 12) {
  // Wait until computed styles look like the real bubble (not raw div)
  for (let i = 0; i < maxFrames; i++) {
    const cs = getComputedStyle(bubble);
    // Heuristic: border-radius and box-shadow become non-trivial when CSS is applied
    if (cs.borderTopLeftRadius !== "0px" && cs.boxShadow && cs.boxShadow !== "none") return true;
    await lwcnNextFrame();
  }
  return false;
}

function lwcnPositionBubbleOnce(bubble, btn) {
  // Position relative to the button, with left/right fallback
  const r = btn.getBoundingClientRect();
  
  // Check if button disappeared
  if ((r.width === 0 && r.height === 0) || r.top === 0 && r.left === 0 && r.bottom === 0 && r.right === 0) {
    return;
  }
  
  // Wait for bubble to be measured
  if (!bubble || bubble.offsetWidth === 0) {
    return;
  }
  
  const br = bubble.getBoundingClientRect();
  const bubbleW = br.width || 360;
  const bubbleH = br.height || 160;

  // Calculate viewport position (fixed positioning uses viewport coordinates)
  let viewportLeft = Math.round(r.left - bubbleW - 12);
  let side = "left";

  // If not enough space on left, place on right
  if (viewportLeft < 8) {
    viewportLeft = Math.round(r.right + 12);
    side = "right";
  }
  
  // Clamp to viewport boundaries
  viewportLeft = Math.max(8, Math.min(window.innerWidth - bubbleW - 8, viewportLeft));

  // Center vertically relative to button
  let viewportTop = Math.round(r.top + (r.height / 2) - (bubbleH / 2));
  
  // Clamp to viewport bounds
  viewportTop = Math.max(8, Math.min(window.innerHeight - bubbleH - 8, viewportTop));

  bubble.style.position = "fixed";
  bubble.style.left = `${viewportLeft}px`;
  bubble.style.top = `${viewportTop}px`;
  bubble.style.zIndex = "2147483647";
  
  if (bubble.dataset) bubble.dataset.side = side;

  // Calculate caret position (arrow pointing to button center)
  const caretTop = r.top + (r.height / 2) - viewportTop;
  if (bubble.style) {
    bubble.style.setProperty("--lwcn-caret-top", `${Math.max(18, Math.min(bubbleH - 18, caretTop))}px`);
  }
}

function lwcnIsTableButton(btn) {
  return !!(btn && btn.dataset && btn.dataset.lwcnTable === "1");
}

function lwcnButtonAllowsPulse(btn) {
  if (!btn) return false;
  if (btn.classList && btn.classList.contains("lwcn-nopulse")) return false;
  if (btn.dataset && btn.dataset.lwcnNoPulse === "1") return false;
  if (lwcnIsTableButton(btn)) return false;
  return true;
}

/**
 * Centralized button state logic.
 * - Order page button: can pulse (lwcn-blink) when there's a note.
 * - Main table injected button: orange but NEVER pulses, and should disappear if note is deleted.
 */
function lwcnSetButtonState(btn, hasNote) {
  if (!btn || !btn.classList) return;
  const on = !!hasNote;

  if (on) {
    btn.classList.add("lwcn-has-note");
    if (lwcnButtonAllowsPulse(btn)) btn.classList.add("lwcn-blink");
    else btn.classList.remove("lwcn-blink");
  } else {
    btn.classList.remove("lwcn-has-note", "lwcn-blink");
    // Table requirement: if note is deleted, hide the button entirely.
    if (lwcnIsTableButton(btn)) {
      try { btn.remove(); } catch {}
    }
  }
}

function renderBubble({ btn, phone_raw, customer_name, noteText, updatedAtText, onChangeText }) {
  closeBubble();

  // יצירת Shadow Host כדי לבודד את העיצוב
  const host = document.createElement("div");
  host.id = "lwcn-shadow-host";
  // Host הגדרות בסיס - full viewport coverage with pointer-events none
  Object.assign(host.style, {
    position: "fixed",
    top: "0",
    left: "0",
    width: "100%",
    height: "100%",
    pointerEvents: "none", // מאפשר קליקים דרך ה-host, רק הבועה תתפוס אותם
    zIndex: "2147483647"
  });
  
  const shadow = host.attachShadow({ mode: "open" });
  
  // הזרקת ה-CSS לתוך ה-Shadow DOM
  const link = document.createElement("link");
  link.rel = "stylesheet";
  link.href = EXT.runtime.getURL("content.css");
  shadow.appendChild(link);

  // Wait for the stylesheet to load BEFORE showing the bubble (prevents unstyled flash + initial jump)
  const waitForCss = () => new Promise((resolve) => {
    let done = false;
    const finish = () => { if (!done) { done = true; resolve(); } };
    link.addEventListener("load", finish, { once: true });
    link.addEventListener("error", finish, { once: true });
    // Safety timeout: never hang if Firefox doesn't fire load for some reason
    setTimeout(finish, 400);
  });
  
  const bubble = document.createElement("div");
  // Start hidden (NOT just opacity=0) so the user never sees a "wrong" position frame.
  bubble.className = "lwcn-bubble lwcn-enter";
  Object.assign(bubble.style, {
    position: "fixed",
    pointerEvents: "auto",
    visibility: "hidden"
  });
  const safeName = escapeHtml(customer_name || "לקוח");
  const noteTextClean = String(noteText || "").trim();
  const hasNote = !!noteTextClean;
  if (hasNote) bubble.classList.add("lwcn-has-note");

  // SVG icons for Shadow DOM (no external dependencies)
  const noteIconSVG = `<svg class="lwcn-titleicon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></svg>`;
  const closeIconSVG = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`;
  // Pencil icon for "updated" line (reused in multiple places)
  const pencilIconSVG = `<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" style="opacity:0.75;margin-left:6px;"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>`;

  bubble.innerHTML = `
    <div class="top">
      <div>
        <div class="title">
          ${noteIconSVG}
          <span>הערות עבור ${safeName}</span>
        </div>
      </div>
      <button class="lwcn-closebtn" data-act="close" title="סגור" aria-label="סגור">
        ${closeIconSVG}
      </button>
    </div>
    <div class="body">
      <textarea class="lwcn-textarea ${hasNote ? "" : "is-empty"}" readonly
        placeholder="לחץ כדי להוסיף הערה..."></textarea>
      <div class="lwcn-autosave-hint">
        <span class="lwcn-dot ok" data-role="dot"></span>
        <span data-role="hint">שמירה אוטומטית</span>
      </div>
      <div class="lwcn-updated" data-role="updated"></div>
    </div>
  `;
  
  // Make bubble respond to pointer events (re-enable after host's pointerEvents: none)
  bubble.style.pointerEvents = "auto";

  const ta = bubble.querySelector(".lwcn-textarea");
  const dot = bubble.querySelector('[data-role="dot"]');
  const updatedEl = bubble.querySelector('[data-role="updated"]');
  const hintEl = bubble.querySelector('[data-role="hint"]');

  // IMPORTANT: set textarea value via .value (prevents leading whitespace/indent bugs)
  ta.value = noteTextClean;

  // updated line (if exists) - pencilIconSVG already defined above
  if (updatedAtText) {
    updatedEl.innerHTML = `${pencilIconSVG} עודכן: ${escapeHtml(updatedAtText)}`;
  } else if (noteText) {
    // Fallback: use current time if we have text but no updated_at
    updatedEl.innerHTML = `${pencilIconSVG} עודכן: ${escapeHtml(formatILDateTime(new Date().toISOString()))}`;
  }

  // auto height - responsive to content
  const MIN_TA_H = 120; // Min height when empty or minimal text
  // Dynamic max height: 55% of viewport or 360px, whichever is smaller
  // This ensures it works well on different screen sizes
  const MAX_TA_H = Math.min(360, Math.floor(window.innerHeight * 0.55));
  
  function autosize() {
    // Reset to auto to get accurate scrollHeight
    ta.style.height = "auto";
    ta.style.overflowY = "hidden"; // Reset overflow
    
    const scrollHeight = ta.scrollHeight;
    const desiredHeight = scrollHeight + 2; // Add small padding for safety
    
    if (desiredHeight <= MIN_TA_H) {
      // Minimal text or empty - use min height
      ta.style.height = MIN_TA_H + "px";
      ta.style.overflowY = "hidden";
    } else if (desiredHeight >= MAX_TA_H) {
      // Long text - use max height with scrollbar
      ta.style.height = MAX_TA_H + "px";
      ta.style.overflowY = "auto";
    } else {
      // Normal text - auto height
      ta.style.height = desiredHeight + "px";
      ta.style.overflowY = "hidden";
    }
  }
  
  // Attach bubble to shadow root first
  shadow.appendChild(bubble);
  
  // Attach shadow host to document (so measurements are reliable)
  document.body.appendChild(host);

  // Wait for CSS to apply, then position once, then fade-in
  (async () => {
    // 1) Ensure Shadow CSS is ready (prevents "raw bubble" flash)
    await waitForCss();
    // 2) Allow DOM attach
    await lwcnNextFrame();
    // 3) Ensure the bubble is measured in its styled state
    await lwcnWaitForStyledBubble(bubble);
    // 4) Position twice BEFORE showing (prevents first-frame jump)
    lwcnPositionBubbleOnce(bubble, btn);
    await lwcnNextFrame();
    lwcnPositionBubbleOnce(bubble, btn);
    // 5) Now show + animate
    bubble.style.visibility = "visible";
    await lwcnNextFrame();
    bubble.classList.add("lwcn-enter--show");
  })();

  // פונקציה לעדכון מיקום בזמן אמת
  // This function tracks the button and updates bubble position continuously
  // משתנים לשמירת המיקום האחרון למניעת רעידות (stabilization)
  let lastTop = null;
  let lastLeft = null;
  let lastSide = null;
  
  function updatePos() {
    const rect = btn.getBoundingClientRect();
    // אם הכפתור נעלם מה-DOM (למשל סגרו את הפאנל), נסגור את הבועה
    if ((rect.width === 0 && rect.height === 0) || 
        (rect.top === 0 && rect.left === 0 && rect.bottom === 0 && rect.right === 0)) {
      closeBubble();
      return;
    }
    
    // Wait for bubble to be measured
    if (!bubble || bubble.offsetWidth === 0) {
      requestAnimationFrame(updatePos);
      return;
    }
    
    const bubbleRect = bubble.getBoundingClientRect();
    const bubbleW = bubbleRect.width || 360;
    const bubbleH = bubbleRect.height || 160;
    
    // Calculate viewport position (fixed positioning uses viewport coordinates)
    // עיגול הערכים למספרים שלמים כדי להתעלם משינויי תת-פיקסל של אנימציות
    let viewportLeft = Math.round(rect.left - bubbleW - 12);
    let side = "left";

    // If not enough space on left, place on right
    if (viewportLeft < 8) {
      viewportLeft = Math.round(rect.right + 12);
      side = "right";
    }
    
    // Clamp to viewport boundaries
    viewportLeft = Math.max(8, Math.min(window.innerWidth - bubbleW - 8, viewportLeft));

    // Center vertically relative to button
    // עיגול הערכים למספרים שלמים כדי להתעלם משינויי תת-פיקסל
    let viewportTop = Math.round(rect.top + (rect.height / 2) - (bubbleH / 2));
    
    // Clamp to viewport bounds
    viewportTop = Math.max(8, Math.min(window.innerHeight - bubbleH - 8, viewportTop));

    // עדכון ה-DOM רק אם השינוי משמעותי (יותר מ-1 פיקסל) או אם זה המיקום הראשון
    // Threshold: Update only if movement > 1px to prevent jittering from pulse animation
    const shouldUpdate = lastTop === null || lastLeft === null || lastSide !== side ||
      Math.abs(viewportTop - lastTop) > 1 || Math.abs(viewportLeft - lastLeft) > 1;

    if (shouldUpdate) {
      // Position the bubble with fixed positioning (relative to viewport)
      bubble.style.position = "fixed";
      bubble.style.left = `${viewportLeft}px`;
      bubble.style.top = `${viewportTop}px`;
      bubble.style.zIndex = "2147483647";
      
      if (bubble.dataset) bubble.dataset.side = side;

      // Calculate caret position (arrow pointing to button center)
      const caretTop = rect.top + (rect.height / 2) - viewportTop;
      if (bubble.style) {
        bubble.style.setProperty("--lwcn-caret-top", `${Math.max(18, Math.min(bubbleH - 18, caretTop))}px`);
      }
      
      // עדכון המיקום האחרון
      lastTop = viewportTop;
      lastLeft = viewportLeft;
      lastSide = side;
    }
  }

  // Store updatePos globally for cleanup
  activeUpdatePos = updatePos;
  
  // Start continuous positioning after initial fade-in
  setTimeout(() => {
    updatePos();
  }, 200); // Start tracking after fade-in completes

  // מאזין לגלילה בכל מקום בדף (כולל בתוך פאנלים)
  // Scroll listener with capture:true to catch scroll events in sidepanels
  activeScrollHandler = () => updatePos();
  window.addEventListener("scroll", activeScrollHandler, { capture: true, passive: true });
  
  // גיבוי למקרה של שינויי DOM מהירים
  // Interval as backup for rapid DOM changes (every 100ms)
  activePositionInterval = setInterval(updatePos, 100);

  // Initial sizing - after attach
  requestAnimationFrame(() => {
    autosize();
    // Reposition after sizing (because height might have changed)
    updatePos();
    // Re-check after fonts/rendering settle
    setTimeout(() => {
      autosize();
      updatePos();
    }, 60);
  });

  let savePending = false;
  let saveTimer = null;

  function setDot(state, msg) {
    dot.classList.remove("ok", "saving", "err");
    if (state === "saving") dot.classList.add("saving");
    else if (state === "err") dot.classList.add("err");
    else dot.classList.add("ok");
    if (msg) hintEl.textContent = msg;
    else hintEl.textContent = "שמירה אוטומטית";
  }

  async function saveNow() {
    // If user cleared the text, treat as "delete"
    const v = String(ta.value || "").trim();
    savePending = true;
    setDot("saving", "שומר…");
    try {
      const res = await onChangeText?.(v);
      setDot("ok", "נשמר");
      // pencilIconSVG already defined in outer scope
      if (res?.updated_at) {
        const f = formatILDateTime(res.updated_at);
        updatedEl.innerHTML = f ? (`${pencilIconSVG} עודכן: ${escapeHtml(f)}`) : "";
      } else {
        updatedEl.innerHTML = `${pencilIconSVG} עודכן: ${escapeHtml(formatILDateTime(new Date().toISOString()))}`;
      }
      ta.classList.toggle("is-empty", !v);
      bubble.classList.toggle("lwcn-has-note", !!v);
      // Update button state
      lwcnSetButtonState(btn, !!v);
    } catch (e) {
      setDot("err", e?.message || "שגיאת שמירה");
    } finally {
      savePending = false;
      autosize();
      // Reposition after save (content might have changed height)
      requestAnimationFrame(() => {
        if (activeUpdatePos) activeUpdatePos();
      });
    }
  }

  function scheduleSave() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => saveNow().catch(() => {}), 450);
  }

  // click-to-edit (same UI)
  ta.addEventListener("click", () => {
    if (ta.hasAttribute("readonly")) {
      ta.removeAttribute("readonly");
      ta.focus();
      // place cursor at end
      const len = ta.value.length;
      ta.setSelectionRange(len, len);
    }
  });

  ta.addEventListener("input", () => {
    autosize();
    // Reposition as user types (content height changes)
    if (activeUpdatePos) activeUpdatePos();
    scheduleSave();
  });

  ta.addEventListener("blur", () => {
    // return to readonly for "view" feel
    ta.setAttribute("readonly", "");
    // Recalculate height after returning to readonly
    requestAnimationFrame(() => {
      autosize();
      if (activeUpdatePos) activeUpdatePos();
    });
  });

  // סגירה חכמה
  const onDoc = (e) => {
    const t = e.target;
    // Check if click is outside shadow host and button
    if (!host.contains(t) && !host.shadowRoot?.contains(t) && t !== btn && !btn.contains(t)) {
      smartClose();
    }
  };
  const onKey = (e) => {
    if (e.key === "Escape") smartClose();
  };

  function cleanupListeners() {
    document.removeEventListener("pointerdown", onDoc, true);
    document.removeEventListener("keydown", onKey, true);
    // If this cleanup is the active one, clear the global reference
    if (activeBubbleCleanup === cleanupListeners) activeBubbleCleanup = null;
  }

  // Make sure closeBubble() can always clean these up
  activeBubbleCleanup = cleanupListeners;

  function smartClose() {
    // if save pending, wait a short moment
    if (savePending) {
      setTimeout(() => { closeBubble(); cleanupListeners(); }, 250);
      return;
    }
    closeBubble();
    cleanupListeners();
  }

  bubble.querySelector('[data-act="close"]').addEventListener("click", smartClose);

  // attach after the opening click finishes (prevents instant close)
  setTimeout(() => {
    document.addEventListener("pointerdown", onDoc, true);
    document.addEventListener("keydown", onKey, true);
  }, 0);

  // Re-position after layout settles (initial render)
  requestAnimationFrame(() => {
    autosize();
    if (activeUpdatePos) activeUpdatePos();
  });
  setTimeout(() => {
    autosize();
    if (activeUpdatePos) activeUpdatePos();
  }, 100);
}

function openEditorPanel({ sbUrl, sbAnon, session, customerKey, phoneRaw, customerName, btn }) {
  closePanel();

  const panel = document.createElement("div");
  panel.className = "lwcn-panel";
  panel.innerHTML = `
    <div class="lwcn-head">
      <div>
        <div class="lwcn-title">הערות עבור ${escapeHtml(customerName || "לקוח")}</div>
        <div class="lwcn-meta">${escapeHtml(phoneRaw || "")}</div>
      </div>
      <button class="lwcn-btn lwcn-btn--icon" title="סגור" style="margin:0;">
        <i class="fa-regular fa-xmark"></i>
      </button>
    </div>

    <div class="lwcn-status"></div>
    <div class="lwcn-editlist"></div>

    <div class="lwcn-actions">
      <button class="lwcn-secondary" data-act="close"><i class="fa-regular fa-circle-xmark"></i> סגור</button>
    </div>
  `;
  document.body.appendChild(panel);

  const status = panel.querySelector(".lwcn-status");
  const listEl = panel.querySelector(".lwcn-editlist");

  const setStatus = (t) => { status.textContent = t || ""; };

  let saveTimer = null;
  let lastSavedValue = null;

  const renderSingle = (existingNote) => {
    const bodyVal = existingNote?.note || "";
    lastSavedValue = bodyVal;

    listEl.innerHTML = `
      <div class="lwcn-note lwcn-note--edit lwcn-single">
        <button class="lwcn-delx" title="מחק הערה">
          <i class="fa-regular fa-xmark"></i>
        </button>
        <textarea class="lwcn-textarea lwcn-textarea--single" placeholder="כתוב הערה...">${escapeHtml(bodyVal)}</textarea>
      </div>
      <div class="lwcn-autosave-hint">שמירה אוטומטית</div>
    `;

    const ta = listEl.querySelector(".lwcn-textarea--single");
    const delX = listEl.querySelector(".lwcn-delx");

    const scheduleSave = () => {
      const v = ta.value;
      if (v === lastSavedValue) {
        setStatus("");
        return;
      }
      if (saveTimer) clearTimeout(saveTimer);
      setStatus("שומר...");
      saveTimer = setTimeout(async () => {
        try {
          await dbSaveSingleNote({
            sbUrl, sbAnon,
            access_token: session.access_token,
            user_id: session.user_id || session.user?.id,
            customer_key: customerKey,
            note: v
          });
          lastSavedValue = v;
          setStatus("נשמר.");

          const hasNotes = String(v || "").trim().length > 0;
          lwcnSetButtonState(btn, hasNotes);
        } catch (e) {
          setStatus(e?.message || "שגיאה בשמירה");
        }
      }, 650);
    };

    ta.addEventListener("input", scheduleSave);

    delX.addEventListener("click", async () => {
      const ok = confirm("למחוק את ההערה הזו לצמיתות?");
      if (!ok) return;
      try {
        setStatus("מוחק...");
        await dbDeleteSingleNote({
          sbUrl, sbAnon,
          access_token: session.access_token,
          customer_key: customerKey
        });
        ta.value = "";
        lastSavedValue = "";
        setStatus("נמחק.");
        lwcnSetButtonState(btn, false);
      } catch (e) {
        setStatus(e?.message || "שגיאה במחיקה");
      }
    });
  };

  async function refresh() {
    const note = await dbGetSingleNote({
      sbUrl, sbAnon,
      access_token: session.access_token,
      customer_key: customerKey
    });
    const hasNotes = !!(note && String(note.note || "").trim());
    lwcnSetButtonState(btn, hasNotes);
    renderSingle(note);
  }

  panel.querySelector(".lwcn-btn").addEventListener("click", closePanel);
  panel.querySelector('[data-act="close"]').addEventListener("click", closePanel);

  refresh().catch((e) => setStatus(e?.message || "שגיאה בטעינת הערות"));
}

function escapeHtml(s) {
  // minimal escape for textarea innerHTML usage
  return String(s)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;");
}

/* ---------------------------
   Main Orders Table injection
   --------------------------- */

/**
 * Cached session wrapper (avoid hammering storage/background for every row).
 */
let lwcnSessionCache = null;
let lwcnSessionCacheAt = 0;

async function ensureSessionCached() {
  const now = Date.now();
  // Reuse for a short window; ensureSession() itself refreshes token when needed.
  if (lwcnSessionCache && (now - lwcnSessionCacheAt) < 15000) return lwcnSessionCache;
  lwcnSessionCache = await ensureSession();
  lwcnSessionCacheAt = now;
  return lwcnSessionCache;
}

// Note existence cache (per customer_key)
const LWCN_TABLE_CACHE_TTL_MS = 2 * 60 * 1000; // 2 minutes
const lwcnTableNoteCache = new Map(); // customerKey -> { note, ts }
const lwcnTableInflight = new Map();  // customerKey -> Promise

// Simple concurrency-limited queue to avoid spamming Supabase
const LWCN_TABLE_MAX_CONCURRENCY = 4;
let lwcnTableActive = 0;
const lwcnTableQueue = [];

function lwcnQueueWork(fn) {
  return new Promise((resolve, reject) => {
    lwcnTableQueue.push({ fn, resolve, reject });
    lwcnPumpQueue();
  });
}

function lwcnPumpQueue() {
  while (lwcnTableActive < LWCN_TABLE_MAX_CONCURRENCY && lwcnTableQueue.length) {
    const job = lwcnTableQueue.shift();
    lwcnTableActive++;
    Promise.resolve()
      .then(job.fn)
      .then(job.resolve, job.reject)
      .finally(() => {
        lwcnTableActive--;
        lwcnPumpQueue();
      });
  }
}

function lwcnCacheSet(customerKey, note) {
  lwcnTableNoteCache.set(customerKey, { note: note || null, ts: Date.now() });
}

async function lwcnGetNoteCached(customerKey) {
  const now = Date.now();
  const cached = lwcnTableNoteCache.get(customerKey);
  if (cached && (now - cached.ts) < LWCN_TABLE_CACHE_TTL_MS) return cached.note;

  const inflight = lwcnTableInflight.get(customerKey);
  if (inflight) return inflight;

  const p = lwcnQueueWork(async () => {
    const { sbUrl, sbAnon, session } = await ensureSessionCached();
    const note = await dbGetSingleNote({
      sbUrl,
      sbAnon,
      access_token: session.access_token,
      customer_key: customerKey
    });
    lwcnCacheSet(customerKey, note);
    return note;
  }).catch((e) => {
    // On auth/network errors, cache "no note" briefly to avoid tight loops.
    lwcnCacheSet(customerKey, null);
    throw e;
  }).finally(() => {
    lwcnTableInflight.delete(customerKey);
  });

  lwcnTableInflight.set(customerKey, p);
  return p;
}

function lwcnNormalizeHeaderText(s) {
  return String(s || "")
    .replace(/\u00a0/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function lwcnFindOrdersTable() {
  // Most reliable: id used by DataTables in Lionwheel
  const byId = document.querySelector("#operator-store-visits-table");
  if (byId) return byId;

  // Fallback: locate by header control attribute
  const th = document.querySelector('th[aria-controls="operator-store-visits-table"]');
  if (th) return th.closest("table");

  return null;
}

function lwcnResolveColumnIndexes(table) {
  const headRow = table?.tHead?.rows?.[0] || table?.querySelector("thead tr");
  if (!headRow) return null;

  const ths = Array.from(headRow.querySelectorAll("th"));
  let nameIdx = -1;
  let phoneIdx = -1;

  for (const th of ths) {
    const t = lwcnNormalizeHeaderText(th.textContent);
    if (!t) continue;
    if (t === "שם" || t.includes("שם")) nameIdx = th.cellIndex;
    if (t === "טלפון" || t.includes("טלפון")) phoneIdx = th.cellIndex;
  }

  if (nameIdx < 0 || phoneIdx < 0) return null;
  return { nameIdx, phoneIdx };
}

function lwcnExtractCellText(td) {
  if (!td) return "";
  const s = String(td.textContent || "").trim();
  return s;
}

function lwcnEnsureTableButton(nameCell, customerKey) {
  const existing = nameCell.querySelector('.lwcn-btn[data-lwcn-table="1"]');
  if (existing && existing.getAttribute("data-customer-key") === customerKey) {
    nameCell.classList.add("lwcn-table-namecell");
    return existing;
  }
  if (existing) existing.remove();

  nameCell.classList.add("lwcn-table-namecell");

  const btn = document.createElement("span");
  btn.className = "lwcn-btn lwcn-nopulse";
  btn.setAttribute("data-lwcn", "1");
  btn.setAttribute("data-lwcn-table", "1");
  btn.setAttribute("data-customer-key", customerKey);
  btn.title = "הערות לקוח";
  btn.innerHTML = `<i class="fa-regular fa-note-sticky" aria-hidden="true"></i>`;

  // Prevent table row / link actions WITHOUT blocking the real click handler.
  // Using pointerdown capture is safe: it won't cancel the later click event.
  btn.addEventListener("pointerdown", (e) => {
    e.preventDefault();
    e.stopPropagation();
  }, true);

  nameCell.appendChild(btn);
  return btn;
}

async function attachNotesButtonsInMainTable() {
  const table = lwcnFindOrdersTable();
  if (!table) return;

  const cols = lwcnResolveColumnIndexes(table);
  if (!cols) return;

  const tbody = table.tBodies?.[0] || table.querySelector("tbody");
  if (!tbody) return;

  const rows = Array.from(tbody.querySelectorAll("tr"));
  if (!rows.length) return;

  // Scan visible rows
  for (const tr of rows) {
    const tds = Array.from(tr.children || []);
    if (!tds.length) continue;

    const nameCell = tds[cols.nameIdx];
    const phoneCell = tds[cols.phoneIdx];
    if (!nameCell || !phoneCell) continue;

    const phoneRaw = lwcnExtractCellText(phoneCell);
    const customerKey = normalizeIsraeliPhoneToE164(phoneRaw);
    if (!customerKey) continue;

    // Avoid repeated work per-row per-key while in-flight
    const marker = `k:${customerKey}`;
    if (tr.dataset && tr.dataset.lwcnTablePending === marker) continue;

    tr.dataset.lwcnTablePending = marker;

    lwcnGetNoteCached(customerKey).then((note) => {
      // Row/cell might have been replaced by DataTables redraw; abort safely.
      if (!document.contains(nameCell)) return;
      const has = !!(note && String(note.note || "").trim());
      if (!has) {
        // Table requirement: hide button if no note exists.
        const b = nameCell.querySelector('.lwcn-btn[data-lwcn-table="1"]');
        if (b && b.getAttribute("data-customer-key") === customerKey) b.remove();
        nameCell.classList.remove("lwcn-table-namecell");
        return;
      }

      const btn = lwcnEnsureTableButton(nameCell, customerKey);
      // Orange, no pulse
      lwcnSetButtonState(btn, true);

      // Attach click handler once
      if (btn.dataset.lwcnClickBound === "1") return;
      btn.dataset.lwcnClickBound = "1";

      btn.addEventListener("click", async (e) => {
        e.preventDefault();
        e.stopPropagation();

        try {
          const { sbUrl, sbAnon, session } = await ensureSessionCached();
          const customerName = lwcnExtractCellText(nameCell);

          let note2 = await dbGetSingleNote({
            sbUrl, sbAnon,
            access_token: session.access_token,
            customer_key: customerKey
          });
          lwcnCacheSet(customerKey, note2);

          renderBubble({
            btn,
            phone_raw: phoneRaw,
            customer_name: customerName,
            noteText: note2?.note || "",
            updatedAtText: fmtUpdatedAt(note2?.updated_at),
            onChangeText: async (newText) => {
              await dbSaveSingleNote({
                sbUrl, sbAnon,
                access_token: session.access_token,
                user_id: session.user_id || session.user?.id,
                customer_key: customerKey,
                note: newText
              });

              // Refresh note (updated_at / deletion)
              note2 = await dbGetSingleNote({
                sbUrl, sbAnon,
                access_token: session.access_token,
                customer_key: customerKey
              });
              lwcnCacheSet(customerKey, note2);

              const has2 = !!(note2 && String(note2.note || "").trim());
              lwcnSetButtonState(btn, has2);

              return note2 || { updated_at: null };
            }
          });

          // Ensure correct style on open
          const has2 = !!(note2 && String(note2.note || "").trim());
          lwcnSetButtonState(btn, has2);

        } catch (e2) {
          // Diagnostics: previously this was fully swallowed, making debugging impossible.
          console.warn("[LWCN][Table] Failed to open bubble", {
            customerKey,
            phoneRaw,
            err: e2?.message || String(e2)
          });
        }
      });

    }).catch(() => {
      // ignore
    }).finally(() => {
      if (tr.dataset && tr.dataset.lwcnTablePending === marker) {
        delete tr.dataset.lwcnTablePending;
      }
    });
  }
}

async function attachOncePerCustomer() {
  const anchor = getAnchorSpanForName();
  const host = getNameHostEl() || anchor?.parentElement || null;
  const phoneRaw = findDestinationPhoneText();
  const customerName = findDestinationNameText();
  if (!host || !phoneRaw || !customerName) return;

  const customerKey = normalizeIsraeliPhoneToE164(phoneRaw);
  if (!customerKey) return;

  // Avoid duplicate button injection:
  const existing = host.querySelector(".lwcn-btn[data-lwcn='1']");
  if (existing?.getAttribute("data-customer-key") === customerKey) return;

  // Remove old button if key changed
  if (existing) existing.remove();

  const btn = document.createElement("span");
  btn.className = "lwcn-btn";
  btn.setAttribute("data-lwcn", "1");
  btn.setAttribute("data-customer-key", customerKey);
  btn.title = "הערות לקוח";

  // FontAwesome note icon (matches what looked good before)
  btn.innerHTML = `<i class="fa-regular fa-note-sticky" aria-hidden="true"></i>`;

  host.appendChild(btn);

  // Load note in background and set badge style
  let cachedNote = null;
  try {
    const { sbUrl, sbAnon, session } = await ensureSession();
    cachedNote = await dbGetSingleNote({
      sbUrl,
      sbAnon,
      access_token: session.access_token,
      customer_key: customerKey
    });
    lwcnCacheSet(customerKey, cachedNote);

    const hasNote = !!(cachedNote && String(cachedNote.note || "").trim());
    lwcnSetButtonState(btn, hasNote);
  } catch {
    // ignore
  }

  btn.addEventListener("click", async () => {
    try {
      const { sbUrl, sbAnon, session } = await ensureSession();

      let note = await dbGetSingleNote({
        sbUrl, sbAnon,
        access_token: session.access_token,
        customer_key: customerKey
      });
      lwcnCacheSet(customerKey, note);

      renderBubble({
        btn,
        phone_raw: phoneRaw,
        customer_name: customerName,
        noteText: note?.note || "",
        updatedAtText: fmtUpdatedAt(note?.updated_at),
        onChangeText: async (newText) => {
          await dbSaveSingleNote({
            sbUrl, sbAnon,
            access_token: session.access_token,
            user_id: session.user_id || session.user?.id,
            customer_key: customerKey,
            note: newText
          });

          // Refresh note to get server-updated updated_at
          note = await dbGetSingleNote({
            sbUrl, sbAnon,
            access_token: session.access_token,
            customer_key: customerKey
          });
          lwcnCacheSet(customerKey, note);

          const has = !!(note && String(note.note || "").trim());
          lwcnSetButtonState(btn, has);

          return note || { updated_at: null };
        }
      });

      // עדכון סטייל
      const has = !!(note && String(note.note || "").trim());
      lwcnSetButtonState(btn, has);

    } catch (e) {
      // אם לא מחובר, תציג bubble עם שגיאה קצרה
      renderBubble({
        btn,
        phone_raw: phoneRaw,
        customer_name: customerName,
        noteText: "",
        updatedAtText: "",
        onChangeText: async () => {}
      });
      const body = document.querySelector(".lwcn-bubble .body");
      if (body) body.innerHTML = `<div class="mini">${escapeHtml(e?.message || "כדי לעבוד: פתח Options והתחבר.")}</div>`;
    }
  });
}

// מניעת ריצות כפולות ושיפור ביצועים
let observerTimeout = null;
const observer = new MutationObserver(() => {
  if (observerTimeout) return; // Skip if already scheduled
  observerTimeout = setTimeout(() => {
    attachOncePerCustomer().catch(() => {});
    attachNotesButtonsInMainTable().catch(() => {});
    observerTimeout = null;
  }, 300);
});

function startObserverSafe() {
  const root = document.body || document.documentElement;
  if (root) {
    observer.observe(root, { childList: true, subtree: true });
    return true;
  }
  return false;
}

// In Firefox (and sometimes in SPA transitions), document.body can be null at script start
if (!startObserverSafe()) {
  window.addEventListener("DOMContentLoaded", () => {
    const r = document.body || document.documentElement;
    if (r) observer.observe(r, { childList: true, subtree: true });
  }, { once: true });
  
  // Also try with boot observer as fallback
  const boot = new MutationObserver(() => {
    if (document.body) {
      boot.disconnect();
      startObserverSafe();
    }
  });
  if (document.documentElement) {
    boot.observe(document.documentElement, { childList: true, subtree: true });
  }
}

(async function initLWCN() {
  await captureMagicLinkSessionIfPresent().catch(() => {});
  // Try a few times because Lionwheel loads panels lazily
  for (let i = 0; i < 20; i++) {
    await attachOncePerCustomer().catch(() => {});
    await attachNotesButtonsInMainTable().catch(() => {});
    await sleep(500);
  }
})();
