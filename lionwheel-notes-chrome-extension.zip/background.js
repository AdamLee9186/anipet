// background.js - Service Worker for Lionwheel Notes Extension
// Handles Supabase API calls and token refresh

// Cross-browser API handle (Chrome + Firefox)
const EXT = globalThis.browser ?? globalThis.chrome;

function nowSec() {
  return Math.floor(Date.now() / 1000);
}

// Ensure NO badge is shown (we moved status indicator into the popup UI)
function clearActionBadge() {
  try {
    const action = EXT.action || EXT.browserAction;
    if (!action?.setBadgeText) return;
    action.setBadgeText({ text: "" });
  } catch (_) {}
}

try {
  EXT.runtime.onInstalled?.addListener(() => clearActionBadge());
  EXT.runtime.onStartup?.addListener(() => clearActionBadge());
} catch (_) {}

// Cross-browser storage wrapper (Firefox returns Promise, Chrome uses callbacks)
async function storageGet(keys) {
  try {
    const maybePromise = EXT.storage.local.get(keys);
    if (maybePromise && typeof maybePromise.then === "function") return maybePromise;
  } catch (_) {}
  return new Promise((resolve, reject) => {
    EXT.storage.local.get(keys, (res) => {
      const err = EXT.runtime?.lastError;
      if (err) reject(err);
      else resolve(res);
    });
  });
}

async function storageSet(obj) {
  try {
    const maybePromise = EXT.storage.local.set(obj);
    if (maybePromise && typeof maybePromise.then === "function") return maybePromise;
  } catch (_) {}
  return new Promise((resolve, reject) => {
    EXT.storage.local.set(obj, () => {
      const err = EXT.runtime?.lastError;
      if (err) reject(err);
      else resolve();
    });
  });
}

async function storageRemove(keys) {
  try {
    const maybePromise = EXT.storage.local.remove(keys);
    if (maybePromise && typeof maybePromise.then === "function") return maybePromise;
  } catch (_) {}
  return new Promise((resolve, reject) => {
    EXT.storage.local.remove(keys, () => {
      const err = EXT.runtime?.lastError;
      if (err) reject(err);
      else resolve();
    });
  });
}

const SB_URL = "https://xfwxplrtetxlyvppfhaf.supabase.co";
const SB_ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhmd3hwbHJ0ZXR4bHl2cHBmaGFmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc5NjQyMjMsImV4cCI6MjA4MzU0MDIyM30.7rg-gAEUM0kCSD2QKLXjz9ZUkwAjzpeYnTPU8tDrHvA";

async function supabaseRefreshToken(sbUrl, sbAnon, refreshToken) {
  const url = `${sbUrl.replace(/\/$/, "")}/auth/v1/token?grant_type=refresh_token`;
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "apikey": sbAnon,
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: `refresh_token=${encodeURIComponent(refreshToken)}`
  });
  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    throw new Error(`Token refresh failed (${res.status}): ${txt}`);
  }
  const data = await res.json();
  return {
    access_token: data.access_token,
    refresh_token: data.refresh_token || refreshToken,
    expires_at: nowSec() + (data.expires_in || 3600) - 30,
    user_id: data.user?.id || null,
    email: data.user?.email || null
  };
}

async function ensureValidSession() {
  const { sbSession } = await storageGet(["sbSession"]);
  if (!sbSession?.access_token) {
    throw new Error("לא מחובר - פתח Options ושלח Magic Link");
  }

  // Check if token is still valid (with 10 second buffer)
  if ((sbSession.expires_at || 0) > nowSec() + 10) {
    return sbSession;
  }

  // Refresh token
  if (!sbSession.refresh_token) {
    throw new Error("פג תוקף - התחבר מחדש");
  }

  const refreshed = await supabaseRefreshToken(SB_URL, SB_ANON, sbSession.refresh_token);
  const merged = { ...sbSession, ...refreshed };
  await storageSet({ sbSession: merged });
  return merged;
}

// Delete note by customer_key
async function deleteNoteByCustomerKey({ access_token, customer_key }) {
  const base = SB_URL.replace(/\/$/, "");
  const url = `${base}/rest/v1/customer_notes?customer_key=eq.${encodeURIComponent(customer_key)}`;

  const res = await fetch(url, {
    method: "DELETE",
    headers: {
      "apikey": SB_ANON,
      "Authorization": `Bearer ${access_token}`
    }
  });

  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`DB delete failed (${res.status}): ${t}`);
  }
}

// Save single note (UPSERT)
async function saveSingleNote({ access_token, user_id, customer_key, note }) {
  const cleanNote = String(note || "").trim();

  // empty => delete
  if (!cleanNote) {
    await deleteNoteByCustomerKey({ access_token, customer_key });
    return null;
  }

  const base = SB_URL.replace(/\/$/, "");
  const url = `${base}/rest/v1/customer_notes?on_conflict=customer_key`;

  const payload = {
    customer_key,
    user_id,
    note: cleanNote,
    updated_at: new Date().toISOString()
  };

  const res = await fetch(url, {
    method: "POST",
    headers: {
      "apikey": SB_ANON,
      "Authorization": `Bearer ${access_token}`,
      "Content-Type": "application/json",
      "Prefer": "resolution=merge-duplicates,return=representation"
    },
    body: JSON.stringify(payload)
  });

  if (!res.ok) {
    const t = await res.text().catch(() => "");
    // Make errors actionable
    if (res.status === 401) throw new Error("לא מחובר — התחבר מחדש (Magic Link).");
    if (res.status === 403) throw new Error("אין הרשאות — בדוק RLS/Policies.");
    if (res.status === 409) throw new Error("קונפליקט DB — בדוק UNIQUE/UPSERT.");
    throw new Error(`שגיאת שמירה (${res.status}): ${t}`);
  }

  const rows = await res.json();
  return rows?.[0] || null;
}

// Get single note by customer_key
async function getSingleNote({ access_token, customer_key }) {
  const base = SB_URL.replace(/\/$/, "");
  const url =
    `${base}/rest/v1/customer_notes` +
    `?select=id,note,updated_at` +
    `&customer_key=eq.${encodeURIComponent(customer_key)}` +
    `&order=updated_at.desc` +
    `&limit=1`;

  const res = await fetch(url, {
    headers: {
      "apikey": SB_ANON,
      "Authorization": `Bearer ${access_token}`
    }
  });

  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`DB read failed (${res.status}): ${t}`);
  }

  const rows = await res.json();
  return rows?.[0] || null;
}

// Message handler from content script
EXT.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.type === "SAVE_NOTE") {
    (async () => {
      try {
        const session = await ensureValidSession();
        const result = await saveSingleNote({
          access_token: session.access_token,
          user_id: session.user_id,
          customer_key: request.data.customer_key,
          note: request.data.note
        });
        sendResponse({ success: true, data: result });
      } catch (error) {
        sendResponse({ success: false, error: error.message });
      }
    })();
    return true; // Keep channel open for async response
  }

  if (request.type === "GET_NOTE") {
    (async () => {
      try {
        const session = await ensureValidSession();
        const result = await getSingleNote({
          access_token: session.access_token,
          customer_key: request.data.customer_key
        });
        sendResponse({ success: true, data: result });
      } catch (error) {
        sendResponse({ success: false, error: error.message });
      }
    })();
    return true; // Keep channel open for async response
  }

  if (request.type === "DELETE_NOTE") {
    (async () => {
      try {
        const session = await ensureValidSession();
        await deleteNoteByCustomerKey({
          access_token: session.access_token,
          customer_key: request.data.customer_key
        });
        sendResponse({ success: true });
      } catch (error) {
        sendResponse({ success: false, error: error.message });
      }
    })();
    return true; // Keep channel open for async response
  }

  if (request.type === "REFRESH_TOKEN") {
    (async () => {
      try {
        const refreshed = await supabaseRefreshToken(SB_URL, SB_ANON, request.data.refreshToken);
        sendResponse({ success: true, data: refreshed });
      } catch (error) {
        sendResponse({ success: false, error: error.message });
      }
    })();
    return true; // Keep channel open for async response
  }

  return false;
});
