// Cross-browser API (Chrome + Firefox)
const EXT = globalThis.browser ?? globalThis.chrome;

async function getStored(keys) {
  try {
    const maybePromise = EXT.storage.local.get(keys);
    if (maybePromise && typeof maybePromise.then === "function") return await maybePromise;
  } catch (_) {}
  return await new Promise((resolve, reject) => {
    EXT.storage.local.get(keys, (res) => {
      const err = EXT.runtime?.lastError;
      if (err) reject(err);
      else resolve(res);
    });
  });
}

async function clearAuth() {
  try {
    const maybePromise = EXT.storage.local.remove(["sbSession"]);
    if (maybePromise && typeof maybePromise.then === "function") return await maybePromise;
  } catch (_) {}
  return await new Promise((resolve, reject) => {
    EXT.storage.local.remove(["sbSession"], () => {
      const err = EXT.runtime?.lastError;
      if (err) reject(err);
      else resolve();
    });
  });
}

function setDot(kind) {
  const dot = document.getElementById("statusDot");
  if (!dot) return;
  dot.classList.remove("green", "yellow", "red");
  if (kind === "ok") dot.classList.add("green");
  else if (kind === "warn") dot.classList.add("yellow");
  else dot.classList.add("red");
}

function setStatus(text, kind) {
  const s = document.getElementById("status");
  s.textContent = `סטטוס: ${text}`;
  s.classList.remove("ok", "bad");
  if (kind === "ok") s.classList.add("ok");
  if (kind === "bad") s.classList.add("bad");

  const tag = document.getElementById("tag");
  if (kind === "ok") tag.textContent = "מחובר";
  else if (kind === "warn") tag.textContent = "בודק";
  else tag.textContent = "מנותק";

  setDot(kind === "ok" ? "ok" : (kind === "warn" ? "warn" : "bad"));
}

async function refresh() {
  // yellow while checking
  setStatus("בודק...", "warn");

  const { sbSession } = await getStored(["sbSession"]);
  const emailEl = document.getElementById("email");

  if (sbSession?.access_token) {
    setStatus("מחובר", "ok");
    // אם בעתיד תמלא email בתוך sbSession (כרגע אצלך זה null)
    const maybeEmail = sbSession.email || "";
    emailEl.textContent = maybeEmail ? `אימייל: ${maybeEmail}` : "";
  } else {
    setStatus("לא מחובר", "bad");
    emailEl.textContent = "לחץ 'הגדרות' להתחברות עם Magic Link";
  }
}

document.getElementById("openOptions").addEventListener("click", async () => {
  // יפתח את options.html
  const url = EXT.runtime.getURL("options.html");
  if (EXT.tabs?.create) EXT.tabs.create({ url });
  else window.open(url, "_blank");
  window.close();
});

document.getElementById("logout").addEventListener("click", async () => {
  await clearAuth();
  await refresh();
});

refresh().catch(() => setStatus("שגיאה בטעינה", "bad"));
