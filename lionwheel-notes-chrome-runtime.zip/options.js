const el = (id) => document.getElementById(id);

function setStatus(text, kind = "neutral") {
  const s = el("status");
  s.textContent = `סטטוס: ${text}`;
  s.classList.remove("ok", "bad");
  if (kind === "ok") s.classList.add("ok");
  if (kind === "bad") s.classList.add("bad");
}

// Cross-browser API (Chrome + Firefox)
const EXT = globalThis.browser ?? globalThis.chrome;

// Cross-browser storage wrapper (Firefox returns Promise, Chrome uses callbacks)
async function getStored(keys) {
  try {
    const maybePromise = EXT.storage.local.get(keys);
    if (maybePromise && typeof maybePromise.then === "function") return await maybePromise;
  } catch (_) {}
  return await new Promise((resolve, reject) => {
    EXT.storage.local.get(keys, (res) => {
      const err = EXT.runtime?.lastError;
      if (err) reject(err);
      else resolve(res);
    });
  });
}

async function setStored(obj) {
  try {
    const maybePromise = EXT.storage.local.set(obj);
    if (maybePromise && typeof maybePromise.then === "function") return await maybePromise;
  } catch (_) {}
  return await new Promise((resolve, reject) => {
    EXT.storage.local.set(obj, () => {
      const err = EXT.runtime?.lastError;
      if (err) reject(err);
      else resolve();
    });
  });
}

async function clearAuth() {
  try {
    const maybePromise = EXT.storage.local.remove(["sbSession"]);
    if (maybePromise && typeof maybePromise.then === "function") return await maybePromise;
  } catch (_) {}
  return await new Promise((resolve, reject) => {
    EXT.storage.local.remove(["sbSession"], () => {
      const err = EXT.runtime?.lastError;
      if (err) reject(err);
      else resolve();
    });
  });
}

// IMPORTANT: hardcode ONLY anon + project url (never sb_secret)
const SB_URL = "https://xfwxplrtetxlyvppfhaf.supabase.co";
const SB_ANON = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inhmd3hwbHJ0ZXR4bHl2cHBmaGFmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3Njc5NjQyMjMsImV4cCI6MjA4MzU0MDIyM30.7rg-gAEUM0kCSD2QKLXjz9ZUkwAjzpeYnTPU8tDrHvA";

async function sendMagicLink(email) {
  const url = `${SB_URL.replace(/\/$/, "")}/auth/v1/otp`;
  // IMPORTANT: Supabase REST expects snake_case email_redirect_to (not emailRedirectTo)
  // Redirect to website (must be added to Supabase Auth Redirect URLs)
  const redirectTo = "https://members.lionwheel.com/";
  const res = await fetch(url, {
    method: "POST",
    headers: {
      "apikey": SB_ANON,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      email,
      create_user: false,
      email_redirect_to: redirectTo,
      redirect_to: redirectTo
    })
  });
  if (!res.ok) {
    const t = await res.text().catch(() => "");
    throw new Error(`שליחת לינק נכשלה (${res.status}): ${t}`);
  }
}

// When user clicks the magic link, Supabase redirects here with tokens in the URL hash.
async function captureSessionFromUrlIfPresent() {
  const hash = (location.hash || "").replace(/^#/, "");
  if (!hash) return false;
  const params = new URLSearchParams(hash);
  const access_token = params.get("access_token");
  const refresh_token = params.get("refresh_token");
  const expires_in = params.get("expires_in");
  if (!access_token || !refresh_token) return false;
  const nowSec = Math.floor(Date.now() / 1000);
  const expires_at = nowSec + (parseInt(expires_in || "3600", 10) || 3600) - 30;
  await setStored({ 
    sbSession: { 
      access_token, 
      refresh_token, 
      expires_at,
      user_id: null,
      email: null
    } 
  });
  // Clean URL (avoid re-capturing)
  history.replaceState(null, "", location.pathname + location.search);
  return true;
}

async function loadUI() {
  const { sbSession } = await getStored(["sbSession"]);
  if (sbSession?.access_token) setStatus(`מחובר`, "ok");
  else setStatus("לא מחובר", "bad");
}

el("sendLink").addEventListener("click", async () => {
  try {
    const email = el("email").value.trim();
    if (!email) {
      setStatus("חסר אימייל", "bad");
      return;
    }
    setStatus("שולח לינק...", "neutral");
    await sendMagicLink(email);
    setStatus("נשלח Magic Link למייל. לחץ עליו כדי להתחבר.", "ok");
    // No OTP verify step needed
    el("verifyOtp").style.display = "none";
  } catch (e) {
    setStatus(e.message || "שגיאה בשליחה", "bad");
  }
});

// Keep the button but disable it in Magic Link mode
el("verifyOtp").style.display = "none";

el("logout").addEventListener("click", async () => {
  await clearAuth();
  setStatus("התנתקת", "bad");
});

loadUI().then(async () => {
  const captured = await captureSessionFromUrlIfPresent().catch(() => false);
  if (captured) {
    setStatus("מחובר בהצלחה (Magic Link)", "ok");
    // Optionally open Lionwheel after successful login
    setTimeout(() => {
      EXT.tabs?.create?.({ url: "https://members.lionwheel.com/" });
    }, 300);
  }
}).catch(() => setStatus("שגיאה בטעינה", "bad"));
